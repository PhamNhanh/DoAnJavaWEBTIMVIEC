package WEBTIMVIEC.example.DoAnLapTrinhJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoAnLapTrinhJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoAnLapTrinhJavaApplication.class, args);
	}

}
