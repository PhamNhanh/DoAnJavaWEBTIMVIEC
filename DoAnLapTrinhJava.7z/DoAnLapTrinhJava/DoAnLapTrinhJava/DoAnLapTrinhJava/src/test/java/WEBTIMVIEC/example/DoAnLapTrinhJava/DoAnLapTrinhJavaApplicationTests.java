package WEBTIMVIEC.example.DoAnLapTrinhJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoAnLapTrinhJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
